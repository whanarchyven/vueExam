<template>
  <h1>Добро пожаловать !</h1>
</template>

<script>
export default {
  name: "Main"
}
</script>

<style scoped>

</style>