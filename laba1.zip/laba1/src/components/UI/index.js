import MyButton from "@/components/UI/MyButton";
import MyInput from "@/components/UI/MyInput";
import ModalWindow from "@/components/UI/ModalWindow";
import MySelect from "@/components/UI/MySelect";
export default [
    MyButton,MyInput,ModalWindow,MySelect
]