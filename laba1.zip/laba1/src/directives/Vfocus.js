export default {
    mounted(el){
        el.focus();
    },
    name:'focus',
}